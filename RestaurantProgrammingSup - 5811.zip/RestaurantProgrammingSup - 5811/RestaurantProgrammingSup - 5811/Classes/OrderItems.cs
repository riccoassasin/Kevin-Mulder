﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantProgrammingSup___5811.Classes
{
    public class OrderItems
    {
        public string Food { get; set; }
        public string Price { get; set; }

        public string Total =>
                //Pizza "(R90)"
                $"{ Price }";

    }
}
