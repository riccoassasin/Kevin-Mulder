﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using RestaurantProgrammingSup___5811.Classes;
using System.Data.SqlClient;

namespace RestaurantProgrammingSup___5811
{
    public class DataAccess
    {
        public List<Forms.Waiters> GetWaiters(string lastName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("KevinRestaurantDB")))
            {
                // Getting data from SQL
                var output = connection.Query<Forms.Waiters>("Select * from Waiters where LastName = ' { lastName }'").ToList();
                return output;
            }
        }

        public void InsertWaiter(string firstName, string lastName, string emailAdress, string phoneNumber)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("KevinRestaurantDB")))
            {
                // Putting Data into SQL
                // Waiters newWaiters = new Waiters { FirstName = firstName, LastName = lastName, EmailAdress = emailAdress, PhoneNumber = phoneNumber };
                List<Waiters> waiters = new List<Waiters>();

                waiters.Add(new Waiters { FirstName = firstName, LastName = lastName, EmailAdress = emailAdress, PhoneNumber = phoneNumber });

                connection.Execute("dbo.Waiters @FirstName, @LastName, @EmailAdress, @PhoneNumber", waiters);

            }
        }
    }
         
                public List<Main> GetFood(string food)
                {
                    using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("KevinRestaurantDB")))
                    {
                        // Getting data from SQL
                        var output = connection.Query<Main>("Select * from Menu where food = ' { food } ' + ' { price } '").ToList();
                        return output;
                    }
                }
                
            

            public void AddFood(string food, string price)
            {
                using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("KevinRestaurantDB")))
                {
                    // Putting Data into SQL
                    List<Main> menu = new List<Main>();

                    menu.Add(new Menu { food = food, price = price });

                    connection.Execute("dbo.Menu @food, @price", menu);

                }
            }

                    public Update<Reservations> GetReservations(string date, string time, int seats, int customerID, string firstName, string phoneNumber)
                    {
                        using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("KevinRestaurantDB")))
                        {
                            // Getting data from SQL
                            var output = connection.Query<Reservations>("Update * from Reservations where FirstName = ' { firstName }'").ToString();
                            return output;
                        }
                    }

                    public void UpdateReservations(string date, string time, int seats, int customerID, string firstName, string phoneNumber)
                    {
                        using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("KevinRestaurantDB")))
                        {
                            // Putting Data into SQL
                            Update<Reservations> update = new Update<Reservations>();

                            reservations.Update(new Reservations { Date = date, Time = time, Seats = seats, CustomerID = customerID, FirstName = firstName, PhoneNumber = phoneNumber });

                            connection.Execute("dbo.Reservations @Date, @Time, @Seats, @CustomerID, @FirstName, @PhoneNumber", reservations);

                        }
                    }

                            public Add<Customers> GetCustomers(string firstName, string lastName, string emailAdress, string phoneNumber, int preferredSeat, int customerID)
                            {
                                using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("KevinRestaurantDB")))
                                {
                                    // Getting data from SQL
                                    var output = connection.Query<Customers>("Select * from Customers where FirstName = ' { firstName }'").ToString();
                                    return output;
                                }
                            }

                            public void AddCustomer(string firstName, string lastName, string emailAdress, string phoneNumber, int preferredSeat, int customerID)
                            {
                                using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("KevinRestaurantDB")))
                                {
                                    // Putting Data into SQL
                                    Add<Customers> customer = new Add<Customers>();

                                    customer.Add(new Customers { FirstName = firstName, LastName = lastName, EmailAdress = emailAdress, PhoneNumber = phoneNumber, PreferredSeat = preferredSeat, ID = customerID });

                                    connection.Execute("dbo.Customers @FirstName, @LastName, @EmailAdress, @PhoneNumber, @PreferredSeat, @ID", customer);

                                }
                            }

}
