﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantProgrammingSup___5811.Classes
{
    public class Waiters
    {
        public int ID { get; set; }
        public string FirstName  { get; set; }
        public string LastName { get; set; }
        public string EmailAdress { get; set; }
        public string PhoneNumber { get; set; }

        public string FullInfo
        {
            get
            {
                // "Kevin Mulder (kwmulder14@gmail.com)"
                return $"{ FirstName } { LastName } ({ EmailAdress })";
            }
        }

    }
}
