﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantProgrammingSup___5811.Classes
{
    public class Customers
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAdress { get; set; }
        public string PhoneNumber { get; set; }
        public int PreferredSeat { get; set; }
        public int ID { get; set; }

    }
}
