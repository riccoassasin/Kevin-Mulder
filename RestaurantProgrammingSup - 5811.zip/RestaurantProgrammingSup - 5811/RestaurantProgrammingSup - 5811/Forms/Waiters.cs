﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantProgrammingSup___5811.Forms
{
    public partial class Waiters : Form
    {
        List<Forms.Waiters> waiters = new List<Forms.Waiters>();
        public Waiters()
        {
            InitializeComponent();

            UpdateBinding();
        }

        private void Waiters_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home ss = new Home();
            ss.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Reservations ss = new Reservations();
            ss.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customers ss = new Customers();
            ss.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main ss = new Main();
            ss.Show();
        }

        private void UpdateBinding()
        {
            waitersFoundListbox.DataSource = waiters;
            waitersFoundListbox.DisplayMember = "FullInfo";
        }
            private void searchButton_Click(object sender, EventArgs e)
            {
                DataAccess db = new DataAccess();

                waiters = db.GetWaiters(lastNameText.Text);

                UpdateBinding();
            }

        private void insertRecord_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();

            db.InsertWaiter(firstNameInsText.Text, lastNameInsText.Text, emailAdressInsText.Text, phoneNumberInsText.Text);

            firstNameInsText.Text = "";
            lastNameInsText.Text = "";
            emailAdressInsText.Text = "";
            phoneNumberInsText.Text = "";
        }
    }
}
