﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RestaurantProgrammingSup___5811
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C: \Users\Kevin Wynand Mulder\Documents\CTU Modules\RestaurantProgrammingSup - 5811\tblLogin.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Select * from tblLogin Where Username = '" + txtUsername.Text.Trim() + "' and Password = '" + txtPassword.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dataTable = new DataTable();
            sda.Fill(dataTable);
            if (dataTable.Rows.Count == 1)
            {
                Main Main = new Main();
                this.Hide();
                Main.Show();
            }
            else
            {
                MessageBox.Show("Check your Username and Password!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Forms.Reservations ss = new Forms.Reservations();
            ss.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Forms.Waiters ss = new Forms.Waiters();
            ss.Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main ss = new Main();
            ss.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Forms.Customers ss = new Forms.Customers();
            ss.Show();

        }

        private void Home_Load(object sender, EventArgs e)
        {

        }
    }
}
