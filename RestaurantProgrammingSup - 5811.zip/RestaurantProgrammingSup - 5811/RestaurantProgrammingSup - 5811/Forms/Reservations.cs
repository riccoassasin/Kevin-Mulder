﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantProgrammingSup___5811.Forms
{
    public partial class Reservations : Form
    {
        public Reservations()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home ss = new Home();
            ss.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customers ss = new Customers();
            ss.Show();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Waiters ss = new Waiters();
            ss.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main ss = new Main();
            ss.Show();
        }

        private void Reservations_Load(object sender, EventArgs e)
        {

        }
    }
}
